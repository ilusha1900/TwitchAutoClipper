"""Offline regression checks for runtime RU/EN translations and saved language."""
import ast
import gc
import json
import os
from pathlib import Path
import string
import tempfile
import unittest
from unittest.mock import patch

from i18n import I18n, _STRINGS
from launcher import parse_number, save_settings


class Variable:
    def set(self, value):
        self.value = value


class Widget:
    alive = True

    def winfo_exists(self):
        return self.alive

    def configure(self, **options):
        self.text = options["text"]

    def title(self, text):
        self.caption = text


class TranslationTests(unittest.TestCase):
    def test_default_fallback_and_valid_languages(self):
        for value in (None, "", "de", 123, [], {}):
            self.assertEqual(I18n(value).language, "ru")
        language = I18n()
        self.assertEqual(language.t("button.start"), "Запустить")
        language.set_language("en")
        self.assertEqual(language.t("button.start"), "Start")
        language.set_language("invalid")
        self.assertEqual(language.language, "en")

    def test_catalogue_key_and_placeholder_parity(self):
        self.assertEqual(set(_STRINGS["ru"]), set(_STRINGS["en"]))
        formatter = string.Formatter()
        for key, russian in _STRINGS["ru"].items():
            english = _STRINGS["en"][key]
            fields = lambda text: {field for _, field, _, _ in formatter.parse(text) if field is not None}
            self.assertEqual(fields(russian), fields(english), key)
            self.assertTrue(english.strip(), key)
            self.assertFalse(any("А" <= c <= "я" or c in "Ёё" for c in english), key)

    def test_referenced_keys_exist(self):
        root = Path(__file__).resolve().parents[1]
        for filename in ("launcher.py", "render_settings.py", "chat_settings.py"):
            tree = ast.parse((root / filename).read_text(encoding="utf-8"))
            for node in ast.walk(tree):
                if isinstance(node, ast.Constant) and isinstance(node.value, str):
                    value = node.value
                    if value.startswith(("render.", "chat.", "status.", "dialog.", "button.", "hint.", "label.", "log.", "error.")) and " " not in value and not value.endswith(".json"):
                        self.assertIn(value, _STRINGS["en"], (filename, value))

    def test_bound_widgets_and_variables_update_without_duplicate_listeners(self):
        language = I18n()
        widget, variable = Widget(), Variable()
        language.bind_text(widget, "button.start")
        language.bind_title(widget, "window.title")
        language.bind_variable(variable, "chat.feedback.initial")
        count = len(language._listeners)
        for _ in range(30):
            language.bind_variable(variable, "chat.feedback.match", label="моя фраза")
        self.assertEqual(len(language._listeners), count)
        language.set_language("en")
        self.assertEqual(widget.text, "Start")
        self.assertIn("recording and editing", widget.caption)
        self.assertEqual(variable.value, "Matched group: моя фраза")
        widget.alive = False
        language.set_language("ru")
        self.assertEqual(len(language._listeners), 1)
        del variable
        gc.collect()
        language.set_language("en")
        self.assertEqual(len(language._listeners), 0)

    def test_chat_validation_errors_translated_without_changing_user_phrases(self):
        language = I18n("en")
        self.assertEqual(language.error("У каждой группы должна быть основная фраза"), "Each group must have a primary phrase")
        self.assertIn("200", language.error("Можно добавить не более 200 групп фраз"))
        self.assertEqual(language.error("Фраза уже добавлена как фраза или вариант: моя фраза"),
                         "The phrase is already added as a phrase or variant: моя фраза")
        self.assertEqual(language.error("External diagnostic"), "External diagnostic")

    def test_atomic_language_roundtrip_and_failed_write(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "settings.json"
            settings = {"channels": "example", "threshold": 1.2, "language": "en", "custom": "оставить"}
            save_settings(path, settings)
            loaded = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(loaded, settings)
            self.assertEqual(I18n(loaded["language"]).language, "en")
            with patch("launcher.os.replace", side_effect=PermissionError("locked")):
                with self.assertRaises(PermissionError):
                    save_settings(path, {**settings, "language": "ru"})
            self.assertEqual(json.loads(path.read_text(encoding="utf-8")), settings)
            self.assertEqual(list(path.parent.glob("*.tmp")), [])

    def test_localized_number_validation(self):
        self.assertEqual(parse_number("1,2", 0.1, 8, "bad"), 1.2)
        for value in ("text", "nan", "inf", "-inf", "0", "9"):
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, "localized message"):
                parse_number(value, 0.1, 8, "localized message")

    def test_trigger_description_language(self):
        from main import describe_trigger
        snapshot = {"thresholds": {"chat": 4.0, "score": 1.2},
                    "routes": ["single_chat", "combined"], "chat_categories": ["react"],
                    "react": 5.0, "score": 2.3, "contributions": {"react": 2.0},
                    "trigger_mode": "escalation", "n_plain": 1, "n_laugh": 2, "n_react": 30}
        with patch.dict(os.environ, CLIP_LANGUAGE="en"):
            description = describe_trigger(snapshot)
            self.assertIn("chat spike", description)
            self.assertIn("reactions=30", description)
            self.assertFalse(any("А" <= c <= "я" for c in description))
        with patch.dict(os.environ, CLIP_LANGUAGE="ru"):
            self.assertIn("всплеск чата", describe_trigger(snapshot))


if __name__ == "__main__":
    unittest.main()
