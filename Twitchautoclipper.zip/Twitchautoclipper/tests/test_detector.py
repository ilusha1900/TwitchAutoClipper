"""Run: python -m unittest -v test_detector"""
import unittest
from detector import MomentDetector, _tokens, is_laugh, is_reaction


class ChatClassificationTests(unittest.TestCase):
    def test_russian_laugh_tokens(self):
        for message in ("ЛОЛ", "лолл", "КЕК", "кекв", "ОРУ", "оруу", "РЖУ",
                        "ржунимагу", "АХАХАХ", "пхаха"):
            with self.subTest(message=message):
                self.assertTrue(any(is_laugh(token) for token in _tokens(message)))

    def test_latin_laughter_and_punctuation(self):
        for message in ("KEKW!", "hahaha", "LUL", "ахах)", "😂"):
            with self.subTest(message=message):
                self.assertTrue(any(is_laugh(token) for token in _tokens(message)))

    def test_reaction_tokens_remain_reactions(self):
        for message in ("F", "Ф", "база", "базированный", "кринж", "рофл"):
            with self.subTest(message=message):
                self.assertTrue(any(is_reaction(token) for token in _tokens(message)))
                self.assertFalse(any(is_laugh(token) for token in _tokens(message)))

    def test_regular_words_are_not_laughter(self):
        for message in ("хорошо", "хохот", "привет", "базар", "фото", "оружие", "lullaby", "Lulu"):
            with self.subTest(message=message):
                self.assertFalse(any(is_laugh(token) for token in _tokens(message)))

    def test_one_category_per_message_and_unique_users(self):
        detector = MomentDetector()
        detector.on_chat("лол база", user="viewer")
        detector.on_chat("ЛОЛ", user="viewer")
        detector.on_chat("база", user="other")
        detector.on_chat("ахах", user="Nightbot")
        self.assertEqual(detector._swap_counts(), {"plain": 0, "laugh": 1, "react": 1})

    def test_one_user_cannot_fill_multiple_categories(self):
        detector = MomentDetector()
        for message in ("привет", "база", "лол", "привет", "база"):
            detector.on_chat(message, user="Viewer")
        self.assertEqual(detector._swap_counts(), {"plain": 0, "laugh": 1, "react": 0})

    def test_empty_message_ignored(self):
        detector = MomentDetector()
        detector.on_chat("  ... ", user="viewer")
        self.assertEqual(detector._swap_counts(), {"plain": 0, "laugh": 0, "react": 0})

    def test_anonymous_messages_are_distinct(self):
        detector = MomentDetector()
        detector.on_chat("лол")
        detector.on_chat("лол")
        self.assertEqual(detector._swap_counts()["laugh"], 2)


class DetectorTickTests(unittest.TestCase):
    def test_tick_updates_last_before_it_is_logged(self):
        detector = MomentDetector()
        detector.on_chat("лол", user="viewer1")
        fired = detector.tick(None, now=100.0)
        snapshot = detector.last
        self.assertEqual(snapshot["t"], 100.0)
        self.assertEqual(snapshot["n_laugh"], 1)
        self.assertEqual(snapshot["n_plain"], 0)
        self.assertEqual(snapshot["n_react"], 0)
        self.assertGreaterEqual(snapshot["laugh"], 0.0)
        self.assertIsInstance(fired, bool)

    def test_raw_counts_are_not_z_scores(self):
        detector = MomentDetector()
        detector.on_chat("лол", user="a")
        detector.on_chat("лол", user="b")
        detector.tick(None, now=1.0)
        self.assertEqual(detector.last["n_laugh"], 2)
        self.assertEqual(detector.last["laugh"], 2.0)

    def test_laughter_alone_can_trigger(self):
        detector = MomentDetector()
        for second in range(30):
            self.assertFalse(detector.tick(None, now=float(second)))
        for viewer in range(40):
            detector.on_chat("лол", user=f"viewer{viewer}")
        self.assertTrue(detector.tick(None, now=30.0))
        self.assertEqual(detector.last["reason"], "single_chat")
        self.assertEqual(detector.last["n_laugh"], 40)
        self.assertLessEqual(detector.last["laugh"], 8)

    def test_cooldown_suppresses_immediate_repeats(self):
        detector = MomentDetector()
        fired = []
        for second in range(15):
            for viewer in range(40):
                detector.on_chat("лол", user=str(viewer))
            if detector.tick(None, now=float(second)):
                fired.append(second)
        self.assertEqual(fired, [0])

    def test_silence_does_not_pollute_audio_history(self):
        detector = MomentDetector()
        for second in range(40):
            detector.tick(-30.0, now=float(second))
        size = len(detector.b["vol"].hist)
        for second in range(40, 340):
            detector.tick(-80.0, now=float(second))
        self.assertEqual(len(detector.b["vol"].hist), size)
        detector.tick(-30.0, now=340.0)
        self.assertLess(detector.last["vol"], 1)

    def test_audio_outage_clears_short_peak(self):
        detector = MomentDetector()
        for second in range(20):
            detector.tick(-40.0, now=float(second))
        detector.tick(-10.0, now=20.0)
        self.assertGreater(detector.last["vol"], 1)
        detector.tick(None, now=21.0)
        detector.tick(-40.0, now=22.0)
        self.assertLess(detector.last["vol"], 1)

    def test_invalid_audio_is_missing(self):
        for value in (None, float("nan"), float("inf"), -80.0):
            with self.subTest(value=value):
                detector = MomentDetector()
                self.assertFalse(detector.tick(value, now=0))
                self.assertFalse(detector.last["has_audio"])

    def test_volume_alone_does_not_trigger(self):
        detector = MomentDetector()
        for second in range(30):
            detector.tick(-40.0, now=float(second))
        self.assertFalse(detector.tick(-5.0, now=30))

    def test_lower_threshold_can_detect_moderate_laughter(self):
        detector = MomentDetector(threshold=1.2, single_threshold=4)
        for second in range(30):
            detector.tick(None, now=second)
        for second in range(30, 34):
            for user in range(5):
                detector.on_chat("лол", user=str(user))
            if detector.tick(None, now=second):
                break
        else:
            self.fail("Moderate sustained laughter should trigger with lower settings")

    def test_audio_alone_does_not_trigger_even_with_low_threshold(self):
        detector = MomentDetector(threshold=0.1, single_threshold=4)
        for second in range(30):
            detector.tick(-40, now=second)
        self.assertFalse(detector.tick(-5, now=30))

    def test_pop_peak_resets(self):
        detector = MomentDetector()
        detector.tick(None, now=0)
        self.assertTrue(detector.pop_peak())
        self.assertEqual(detector.pop_peak(), {})

    def test_counts_reset_between_ticks(self):
        detector = MomentDetector()
        detector.on_chat("лол", user="a")
        detector.tick(None, now=0)
        detector.tick(None, now=1)
        self.assertEqual(detector.last["n_laugh"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
