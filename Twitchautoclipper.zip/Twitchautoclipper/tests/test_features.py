"""Offline regression tests for FPS variation, CapCut tags and custom chat phrases."""
from fractions import Fraction
import json
from pathlib import Path
import struct
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock, Mock, patch

from chat_settings import (ChatConfigReloader, PhraseMatcher, read_config, save_config,
                           validate_config, MAX_BYTES)
from detector import MomentDetector
import montage
from mp4_metadata import finalize_encoder_tag


def config(phrase="вот это момент", variants=None, enabled=True):
    return {"enabled": enabled, "phrases": [{"phrase": phrase, "variants": variants or []}]}


class ChatPhraseTests(unittest.TestCase):
    def test_phrase_variants_case_spacing_and_boundaries(self):
        matcher = PhraseMatcher(config(variants=["вотэтода", "ничего себе"]))
        for message in ("Вот Это Момент!", "ого, ВОТ   ЭТО\tМОМЕНТ!!!", "ВОТЭТОДА", "ну ничего себе..."):
            self.assertEqual(matcher.match(message), "вот это момент")
        for message in ("вот это моментик", "сверхвотэтода", "ничего себестоимость", "обычное сообщение"):
            self.assertIsNone(matcher.match(message))

    def test_literal_not_regex_and_unicode(self):
        matcher = PhraseMatcher(config("[wow]+", ["a.*b", "ＧＧ", "🔥"]))
        for message in ("[wow]+", "literal a.*b!", "gg", "WOW🔥"):
            self.assertIsNotNone(matcher.match(message))
        self.assertIsNone(matcher.match("axxxb"))
        self.assertIsNone(matcher.match("bigger"))

    def test_disabled_and_default_empty(self):
        self.assertIsNone(PhraseMatcher(config(enabled=False)).match("вот это момент"))
        self.assertIsNone(PhraseMatcher().match("hello"))

    def test_rejects_malformed_or_excessive_input(self):
        for invalid in ([], {"enabled": "yes"}, {"phrases": "bad"},
                        config(""), config("a" * 161), config(variants=["x"] * 31),
                        {"phrases": [{"phrase": "abc", "variants": "def"}]},
                        {"phrases": [{"phrase": 123}]}, config(variants=[None])):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                validate_config(invalid)

    def test_duplicates_normalized_and_primary_collision_rejected(self):
        data = validate_config(config("Wow", ["wow", " WOW ", "другое"]))
        self.assertEqual(data["phrases"][0]["variants"], ["другое"])
        with self.assertRaises(ValueError):
            validate_config({"phrases": [{"phrase": "Wow"}, {"phrase": "WOW"}]})

    def test_atomic_roundtrip_and_failed_replace_preserves_existing(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "chat.json"
            self.assertEqual(read_config(path), {"enabled": True, "phrases": []})
            data = config(variants=["другая фраза"])
            self.assertEqual(save_config(path, data), data)
            self.assertEqual(read_config(path), data)
            with patch("chat_settings.os.replace", side_effect=PermissionError("locked")):
                with self.assertRaises(PermissionError):
                    save_config(path, config("new phrase"))
            self.assertEqual(read_config(path), data)
            self.assertEqual(list(path.parent.glob("*.tmp")), [])

    def test_oversized_file_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "chat.json"
            path.write_text(" " * (MAX_BYTES + 1))
            with self.assertRaises(ValueError):
                read_config(path)

    def test_hot_reload_invalid_settings_and_delete(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "chat.json"
            notify = Mock()
            loader = ChatConfigReloader(path, notify)
            self.assertIsNone(loader.poll().match("hello"))
            self.assertIsNone(loader.poll())
            save_config(path, config("hello"))
            previous = loader.poll()
            self.assertEqual(previous.match("hello"), "hello")
            path.write_text("broken json", encoding="utf-8")
            self.assertIsNone(loader.poll())
            count = notify.call_count
            self.assertIsNone(loader.poll())
            self.assertEqual(notify.call_count, count)
            self.assertEqual(previous.match("hello"), "hello")
            save_config(path, config("goodbye"))
            self.assertEqual(loader.poll().match("goodbye"), "goodbye")
            path.unlink()
            self.assertIsNone(loader.poll().match("goodbye"))
        self.assertIsNone(ChatConfigReloader(None).poll())

    def test_classification_bot_filter_dedup_and_laugh_priority(self):
        detector = MomentDetector()
        detector.set_chat_matcher(PhraseMatcher(config("awesome", ["super moment"])))
        detector.on_chat("normal", "alice")
        detector.on_chat("AWESOME!", "alice")
        detector.on_chat("awesome", "alice")
        detector.on_chat("super moment", "bob")
        detector.on_chat("awesome KEKW", "carol")
        detector.on_chat("awesome", "NightBot")
        detector.on_chat("normal", "dave")
        self.assertEqual(detector._swap_counts(), {"plain": 1, "react": 2, "laugh": 1})
        detector.set_chat_matcher(PhraseMatcher())
        detector.on_chat("awesome", "alice")
        detector.on_chat("осуждаю", "bob")
        self.assertEqual(detector._swap_counts(), {"plain": 1, "react": 1, "laugh": 0})

    def test_punctuation_only_custom_message_is_not_discarded(self):
        detector = MomentDetector()
        detector.set_chat_matcher(PhraseMatcher(config("!!!")))
        detector.on_chat("!!!", "alice")
        detector.on_chat(" ", "bob")
        self.assertEqual(detector._swap_counts(), {"plain": 0, "react": 1, "laugh": 0})

    def test_signal_not_instant_clip_and_cooldown_preserved(self):
        detector = MomentDetector(threshold=1.2, single_threshold=4)
        detector.set_chat_matcher(PhraseMatcher(config("awesome")))
        detector.on_chat("awesome", "alice")
        self.assertFalse(detector.tick(None, now=0))
        for i in range(40):
            detector.on_chat("awesome", f"u{i}")
        self.assertTrue(detector.tick(None, now=50))
        self.assertEqual(detector.last["n_react"], 40)
        self.assertIn("react", detector.last["chat_categories"])
        for i in range(40):
            detector.on_chat("awesome", f"u{i}")
        self.assertFalse(detector.tick(None, now=51))


class FPSTests(unittest.TestCase):
    def test_exact_offsets_positive_rates_and_variety(self):
        for base in (Fraction(30), Fraction(30000, 1001), Fraction(60), Fraction(1, 20)):
            samples = {montage.choose_output_fps(base) for _ in range(300)}
            self.assertGreater(len(samples), 5)
            for sample in samples:
                self.assertGreater(sample, 0)
                self.assertTrue(Fraction(1, 10) <= abs(sample - base) <= 2)
                self.assertEqual((sample - base) * 10, int((sample - base) * 10))
            self.assertEqual(montage.choose_output_fps(base, False), base)

    def test_invalid_rates(self):
        for rate in (0, -1, 1001, "nan", "0/0"):
            with self.subTest(rate=rate), self.assertRaises((ValueError, ZeroDivisionError)):
                montage.choose_output_fps(rate)

    def test_probe_average_nominal_and_fallback(self):
        for stream, expected in (({"avg_frame_rate": "30000/1001", "r_frame_rate": "30/1"}, Fraction(30000, 1001)),
                                 ({"avg_frame_rate": "0/0", "r_frame_rate": "60/1"}, 60),
                                 ({"avg_frame_rate": "nan", "r_frame_rate": "0/0"}, 30)):
            result = SimpleNamespace(stdout=json.dumps({"streams": [stream]}))
            with patch.object(montage, "run_tool", return_value=result), patch.object(montage, "tool", return_value="ffprobe"):
                self.assertEqual(montage.probe_fps("input.mp4"), expected)


class MP4TagTests(unittest.TestCase):
    @staticmethod
    def atom(kind, content):
        return struct.pack(">I4s", 8 + len(content), kind) + content

    def test_only_metadata_key_bytes_change_not_mdat_or_offsets(self):
        atom = self.atom
        keys = atom(b"keys", b"\0" * 4 + struct.pack(">I", 1) + atom(b"mdta", b"appname"))
        data = atom(b"ftyp", b"isom\0\0\0\0") + atom(b"moov", atom(b"udta", atom(b"meta", b"\0" * 4 + keys)))
        media = atom(b"mdat", b"appname CapCut encoder this is video data")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "out.mp4"
            path.write_bytes(data + media)
            finalize_encoder_tag(path)
            result = path.read_bytes()
            self.assertEqual(len(result), len(data + media))
            self.assertEqual(result[-len(media):], media)
            self.assertEqual(result, data.replace(b"appname", b"encoder") + media)

    def test_bad_atoms_or_missing_key_fail_without_writing(self):
        for data in (b"", b"bad", self.atom(b"mdat", b"appname"),
                     struct.pack(">I4s", 9999, b"moov")):
            with self.subTest(data=data), tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "bad.mp4"
                path.write_bytes(data)
                with self.assertRaises(ValueError):
                    finalize_encoder_tag(path)
                self.assertEqual(path.read_bytes(), data)


class ChatEditorTests(unittest.TestCase):
    def test_window_construction_and_action_bindings_without_display(self):
        from chat_settings import ChatPhraseEditor
        tk, ttk, messagebox = MagicMock(), MagicMock(), MagicMock()
        tk.ttk, tk.messagebox = ttk, messagebox
        with tempfile.TemporaryDirectory() as directory, patch.dict("sys.modules", {
                "tkinter": tk, "tkinter.ttk": ttk, "tkinter.messagebox": messagebox}):
            editor = ChatPhraseEditor(MagicMock(), Path(directory) / "chat.json", Mock())
        tk.Toplevel.assert_called_once()
        editor.window.protocol.assert_called_once_with("WM_DELETE_WINDOW", editor.close)
        # Translated button text is now applied after construction via I18n.
        buttons = {call.kwargs["command"].__name__: call.kwargs["command"] for call in ttk.Button.call_args_list}
        self.assertEqual(buttons["save"], editor.save)
        self.assertEqual(buttons["commit"], editor.commit)
        self.assertEqual(buttons["delete"], editor.delete)
        self.assertEqual(buttons["check"], editor.check)

    def editor(self, path):
        from chat_settings import ChatPhraseEditor
        class Variable:
            def __init__(self, value=""):
                self.value = value
            def get(self):
                return self.value
            def set(self, value):
                self.value = value
        class Text:
            def __init__(self):
                self.value = ""
            def get(self, *args):
                return self.value
            def delete(self, *args):
                self.value = ""
            def insert(self, index, value):
                self.value = value
            def edit_modified(self, *args):
                return False
        editor = ChatPhraseEditor.__new__(ChatPhraseEditor)
        from i18n import I18n
        editor.i18n = I18n()
        editor.path, editor.notify = path, Mock()
        editor.messagebox, editor.window = Mock(), Mock()
        editor.tree, editor.entry = Mock(), Mock()
        editor.tree.get_children.return_value = ()
        editor.tree.selection.return_value = ()
        editor.data = read_config(path)
        editor.enabled, editor.phrase = Variable(True), Variable()
        editor.preview, editor.feedback = Variable(), Variable()
        editor.variants = Text()
        editor.selected, editor.dirty, editor.loading = None, False, False
        return editor

    def test_add_edit_variant_preview_save_and_delete(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "chat.json"
            editor = self.editor(path)
            editor.phrase.set("Супер момент")
            editor.variants.insert("1.0", "вотэтода\nВАУ\n")
            editor.save()  # Save also commits an unfinished draft.
            self.assertFalse(editor.dirty)
            self.assertEqual(read_config(path)["phrases"], [{"phrase": "Супер момент", "variants": ["вотэтода", "ВАУ"]}])
            editor.preview.set("ВаУ!")
            editor.check()
            self.assertIn("Супер момент", editor.feedback.get())
            editor.phrase.set("Другой момент")
            editor.save()
            self.assertEqual(read_config(path)["phrases"][0]["phrase"], "Другой момент")
            editor.delete()
            editor.save()
            self.assertEqual(read_config(path)["phrases"], [])

    def test_switch_group_commits_draft_and_new_does_not_lose_edits(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "chat.json"
            editor = self.editor(path)
            editor.phrase.set("first")
            editor.commit()
            editor.new()
            editor.phrase.set("second")
            editor.commit()
            editor.phrase.set("second edited")
            editor.tree.selection.return_value = ("0",)
            editor.select()
            self.assertEqual(editor.selected, 0)
            self.assertEqual(editor.phrase.get(), "first")
            self.assertEqual(editor.data["phrases"][1]["phrase"], "second edited")
            editor.phrase.set("first edited")
            editor.new()
            self.assertIsNone(editor.selected)
            self.assertEqual(editor.data["phrases"][0]["phrase"], "first edited")

    def test_invalid_draft_does_not_replace_config_and_cancel_keeps_window(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "chat.json"
            save_config(path, config("original"))
            editor = self.editor(path)
            editor.phrase.set("x" * 161)
            editor.save()
            self.assertEqual(read_config(path), config("original"))
            editor.messagebox.showerror.assert_called_once()
            editor.messagebox.askyesnocancel.return_value = None
            editor.close()
            editor.window.destroy.assert_not_called()

    def test_load_fields_does_not_mark_unsaved_and_disabled_roundtrip(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "chat.json"
            editor = self.editor(path)
            editor.load_fields()
            self.assertFalse(editor.dirty)
            editor.enabled.set(False)
            editor.save()
            self.assertFalse(read_config(path)["enabled"])


class RealFeatureMediaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            cls.ffmpeg = montage.tool("ffmpeg")
            cls.ffprobe = montage.tool("ffprobe")
        except FileNotFoundError as error:
            raise unittest.SkipTest(str(error))

    def test_actual_source_relative_fps_capcut_and_audio_timing(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for index, (rate, delta) in enumerate((("25", -2), ("30000/1001", 0.1), ("60", 2))):
                with self.subTest(source_rate=rate, delta=delta):
                    source = root / f"input{index}.mp4"
                    montage.run_tool([self.ffmpeg, "-v", "error", "-y", "-f", "lavfi", "-i",
                                      f"testsrc2=size=160x90:rate={rate}", "-f", "lavfi", "-i",
                                      "sine=frequency=440:sample_rate=48000", "-t", "3",
                                      "-c:v", "libx264", "-preset", "ultrafast", "-c:a", "aac", str(source)],
                                     capture_output=True)
                    options = {"banner": "", "music": "", "split_camera": False,
                               "video_variation": False, "random_metadata": index != 1}
                    job = {"channel": "test", "path": str(source), "ts": index + 1,
                           "offset": 0.2, "duration": 2.5}
                    with patch.object(montage, "OUT_DIR", str(root / "ready")), \
                         patch.object(montage, "read_options", return_value=options), \
                         patch.object(montage.random, "choice", return_value=Fraction(str(delta))), \
                         patch.dict(montage.SUBS, enabled=False):
                        out, _, _ = montage.make_vertical(job)
                    raw = montage.run_tool([self.ffprobe, "-v", "error", "-show_streams", "-show_format",
                                            "-of", "json", out], capture_output=True, text=True).stdout
                    actual = json.loads(raw)
                    video, audio = actual["streams"]
                    expected = Fraction(rate) + Fraction(str(delta))
                    self.assertEqual(Fraction(video["r_frame_rate"]), expected)
                    self.assertEqual(Fraction(video["avg_frame_rate"]), expected)
                    self.assertEqual(Fraction(job["render"]["output_fps_ratio"]), expected)
                    self.assertEqual((video["width"], video["height"]), (1080, 1920))
                    self.assertLess(abs(float(video["duration"]) - 2.5), 2 / float(expected))
                    self.assertLess(abs(float(audio["duration"]) - 2.5), 0.05)
                    self.assertLess(abs(float(video["duration"]) - float(audio["duration"])), 0.1)
                    self.assertEqual(audio["sample_rate"], "48000")
                    for key in ("encoder", "encoding_tool", "producer"):
                        self.assertEqual(actual["format"]["tags"][key], "CapCut")
                    for marker in ("Lavc", "Lavf", "appname"):
                        self.assertNotIn(marker, raw)
                    # Decode all video frames and audio to detect broken MP4 offsets.
                    montage.run_tool([self.ffmpeg, "-v", "error", "-i", out, "-f", "null", "-"], capture_output=True)
                    self.assertTrue(source.exists())
                    self.assertGreater(Path(out).stat().st_size, 0)


if __name__ == "__main__":
    unittest.main()
