"""Installer tests: no network, no Windows binaries and no package installation."""
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch, MagicMock
import zipfile
import setup_dependencies as setup


class SetupTests(unittest.TestCase):
    def test_wrong_os_fails_before_installation(self):
        with patch.object(setup.sys, 'platform', 'linux'), patch.object(setup, 'prepare_environment') as prepare:
            with patch('sys.stderr', new_callable=io.StringIO):
                self.assertEqual(setup.main([]), 1)
            prepare.assert_not_called()

    def test_working_venv_is_reused(self):
        with tempfile.TemporaryDirectory() as work:
            root = Path(work)
            python = root / '.venv/Scripts/python.exe'
            python.parent.mkdir(parents=True)
            python.write_bytes(b'placeholder')
            with patch.object(setup, 'ROOT', root), patch.object(setup, 'run',
                    return_value=SimpleNamespace(stdout=json.dumps(str(root / '.venv')))) as run:
                self.assertEqual(setup.prepare_environment(), python)
            self.assertEqual(run.call_count, 1)
            self.assertFalse(list(root.glob('.venv.backup_*')))

    def test_broken_copied_venv_is_backed_up(self):
        with tempfile.TemporaryDirectory() as work:
            root = Path(work)
            python = root / '.venv/Scripts/python.exe'
            python.parent.mkdir(parents=True)
            python.write_bytes(b'placeholder')
            marker = root / '.venv/keep.txt'
            marker.write_text('keep me')
            with patch.object(setup, 'ROOT', root), patch.object(setup, 'run',
                    side_effect=[OSError('old Python path'), MagicMock(), MagicMock()]) as run:
                setup.prepare_environment()
            backups = list(root.glob('.venv.backup_*'))
            self.assertEqual(len(backups), 1)
            self.assertEqual((backups[0] / 'keep.txt').read_text(), 'keep me')
            self.assertEqual(run.call_args_list[1].args[0][1:4], ['-I', '-m', 'venv'])

    def test_no_ffmpeg_download_when_tools_work(self):
        with patch.object(setup, 'available_tool', return_value='available'), patch.object(setup, 'download_archive') as download:
            setup.ensure_ffmpeg()
            download.assert_not_called()

    def test_archive_only_copies_exact_tools(self):
        with tempfile.TemporaryDirectory() as work:
            root = Path(work)
            archive = root / 'test.zip'
            with zipfile.ZipFile(archive, 'w') as out:
                out.writestr('ffmpeg/bin/ffmpeg.exe', b'MZffmpeg')
                out.writestr('ffmpeg/bin/ffprobe.exe', b'MZffprobe')
                out.writestr('../planted.py', 'raise RuntimeError()')
                out.writestr('ffmpeg/install.cmd', 'bad command')
            destination = root / 'staging'
            destination.mkdir()
            setup.extract_tools(archive, destination)
            self.assertEqual(sorted(path.name for path in destination.iterdir()), ['ffmpeg.exe', 'ffprobe.exe'])
            self.assertFalse((root / 'planted.py').exists())

    def test_duplicate_and_non_executable_tools_rejected(self):
        for duplicate in (False, True):
            with self.subTest(duplicate=duplicate), tempfile.TemporaryDirectory() as work:
                root = Path(work)
                archive = root / 'test.zip'
                with zipfile.ZipFile(archive, 'w') as out:
                    out.writestr('one/bin/ffmpeg.exe', b'MZbinary' if duplicate else b'not an exe')
                    out.writestr('one/bin/ffprobe.exe', b'MZbinary')
                    if duplicate:
                        out.writestr('two/bin/ffmpeg.exe', b'MZbinary')
                with self.assertRaises(RuntimeError):
                    setup.extract_tools(archive, root)

    def test_staged_install_and_cleanup(self):
        with tempfile.TemporaryDirectory() as work:
            root = Path(work)
            def extract(archive, target):
                for name in ('ffmpeg.exe', 'ffprobe.exe'):
                    (target / name).write_bytes(b'MZbinary')
            with patch.object(setup, 'ROOT', root), patch.object(setup, 'available_tool', return_value=None), \
                 patch.object(setup, 'download_archive'), patch.object(setup, 'extract_tools', side_effect=extract), \
                 patch.object(setup, 'tool_works', return_value=True):
                setup.ensure_ffmpeg()
            self.assertEqual(sorted(path.name for path in (root / 'bin').iterdir()), ['ffmpeg.exe', 'ffprobe.exe'])

    def test_failed_download_does_not_replace_existing_tool(self):
        with tempfile.TemporaryDirectory() as work:
            root = Path(work)
            (root / 'bin').mkdir()
            (root / 'bin/ffmpeg.exe').write_bytes(b'old binary')
            with patch.object(setup, 'ROOT', root), patch.object(setup, 'available_tool', return_value=None), \
                 patch.object(setup, 'download_archive', side_effect=OSError('offline')):
                with self.assertRaisesRegex(RuntimeError, 'FFmpeg'):
                    setup.ensure_ffmpeg()
            self.assertEqual((root / 'bin/ffmpeg.exe').read_bytes(), b'old binary')
            self.assertEqual(list((root / 'bin').glob('roma_ffmpeg_*')), [])

    def test_subtitles_are_optional(self):
        for enabled in (False, True):
            with self.subTest(enabled=enabled), patch.object(setup, 'run') as run:
                setup.install_packages(Path('python.exe'), enabled)
                commands = [str(call.args[0]) for call in run.call_args_list]
                self.assertEqual(any('faster-whisper' in command for command in commands), enabled)
                self.assertTrue(any("'pip', 'check'" in command for command in commands))

    def test_batch_has_crlf_and_valid_label_targets(self):
        import re
        content = (Path(setup.__file__).parent / 'setup.cmd').read_bytes()
        self.assertTrue(content.startswith(b'@echo off\r\n'))
        self.assertNotIn(b'\n', content.replace(b'\r\n', b''))
        text = content.decode('utf-8')
        labels = set(re.findall(r'^:([a-z_]+)', text, re.M | re.I))
        targets = re.findall(r'(?:goto|call) :([a-z_]+)', text, re.I)
        self.assertTrue(set(targets) <= labels)
        self.assertIn('DisableDelayedExpansion', text)
        self.assertIn('"%~dp0setup_dependencies.py" %*', text)
        self.assertIn('call "%~dp0start.cmd"', text)


if __name__ == '__main__':
    unittest.main()
