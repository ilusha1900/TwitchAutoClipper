"""Synthetic, offline FFmpeg checks. Does not connect to Twitch."""
import os
from pathlib import Path
import tempfile
import montage


def run():
    previous = Path.cwd()
    # Resolve tools before entering the isolated temporary work directory.
    ffmpeg = montage.tool("ffmpeg")
    ffprobe = montage.tool("ffprobe")
    old_env = {key: os.environ.get(key) for key in ("FFMPEG_PATH", "FFPROBE_PATH", "CLIP_RENDER_CONFIG")}
    old_banner = montage.SPONSOR["banner"]
    old_music = dict(montage.MUSIC)
    old_subs = montage.SUBS["enabled"]
    try:
        os.environ["FFMPEG_PATH"], os.environ["FFPROBE_PATH"] = ffmpeg, ffprobe
        os.environ.pop("CLIP_RENDER_CONFIG", None)
        from main import preflight
        preflight(check_streamlink=False)
        with tempfile.TemporaryDirectory(prefix="twitch_clipper_check_") as directory:
            os.chdir(directory)
            try:
                montage.SUBS["enabled"] = False
                montage.SPONSOR["banner"] = None
                montage.MUSIC["enabled"] = False
                base = [ffmpeg, "-loglevel", "error", "-y"]
                montage.run_tool(base + ["-f", "lavfi", "-i", "testsrc2=size=640x360:rate=30",
                                        "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000",
                                        "-t", "4", "-c:v", "libx264", "-preset", "ultrafast",
                                        "-pix_fmt", "yuv420p", "-c:a", "aac", "sample.mp4"])
                job = {"channel": "smoketest", "path": str(Path("sample.mp4").resolve()),
                       "ts": 1, "offset": 0.5, "duration": 3.0}
                out, _, sponsored = montage.make_vertical(job)
                if montage.probe_size(out) != (1080, 1920) or sponsored:
                    raise RuntimeError("Basic vertical output check failed")
                if abs(montage.probe_duration(out) - 3.0) > 0.5:
                    raise RuntimeError("Output duration check failed")
                Path("music").mkdir()
                montage.run_tool(base + ["-f", "lavfi", "-i", "sine=frequency=220:sample_rate=48000",
                                        "-t", "1", "music/tone.wav"])
                montage.run_tool(base + ["-f", "lavfi", "-i", "color=c=0x00ff00:s=320x100:r=30",
                                        "-vf", "drawbox=x=20:y=20:w=200:h=60:color=red:t=fill",
                                        "-t", "1", "-c:v", "libx264", "-pix_fmt", "yuv420p", "sponsor.mp4"])
                montage.SPONSOR["banner"] = "sponsor.mp4"
                montage.MUSIC["enabled"] = True
                montage.MUSIC["dir"] = "music"
                job["ts"] = 2
                out, _, sponsored = montage.make_vertical(job)
                if not sponsored or montage.probe_size(out) != (1080, 1920):
                    raise RuntimeError("Music/banner graph check failed")
                if abs(montage.probe_duration(out) - 3.0) > 0.5:
                    raise RuntimeError("Looped music/banner duration check failed")
                # Validate actual top-camera / lower-content placement using known colours.
                from render_settings import save_options
                montage.run_tool(base + ["-f", "lavfi", "-i", "color=c=blue:s=640x360:r=30",
                                        "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000",
                                        "-vf", "drawbox=x=32:y=36:w=160:h=108:color=red:t=fill",
                                        "-t", "3", "-c:v", "libx264", "-preset", "ultrafast", "-c:a", "aac", "colours.mp4"])
                render_path = Path("render_test.json").resolve()
                save_options(render_path, {"split_camera": True,
                    "banner": str(Path("sponsor.mp4").resolve()), "music": str(Path("music/tone.wav").resolve()),
                    "crops": {"smoketest": {"camera": [0.05, 0.1, 0.25, 0.3], "content": [0.3, 0, 0.7, 1]}}})
                os.environ["CLIP_RENDER_CONFIG"] = str(render_path)
                job.update(path=str(Path("colours.mp4").resolve()), ts=3, offset=0, duration=3)
                out, _, sponsored = montage.make_vertical(job)
                if montage.probe_size(out) != (1080, 1920) or not sponsored:
                    raise RuntimeError("Split layout output failed")
                frame = montage.run_tool([ffmpeg, "-loglevel", "error", "-i", out, "-frames:v", "1",
                                          "-vf", "scale=108:192", "-f", "rawvideo", "-pix_fmt", "rgb24", "pipe:1"],
                                         capture_output=True).stdout
                top = frame[(32 * 108 + 54) * 3:(32 * 108 + 54) * 3 + 3]
                bottom = frame[(128 * 108 + 54) * 3:(128 * 108 + 54) * 3 + 3]
                if not (top[0] > 150 and top[2] < 100 and bottom[2] > 150 and bottom[0] < 100):
                    raise RuntimeError(f"Camera/content placement incorrect: top={list(top)}, bottom={list(bottom)}")
                check_video_effects(base, render_path)
                os.environ.pop("CLIP_RENDER_CONFIG", None)
                # Real, long-GOP segment manifest: first segment begins well before
                # the requested window, reproducing the original lo-2 selection bug.
                import json
                import queue
                import threading
                from main import ChannelCtx, cut_clip, list_segments, select_run
                segment_dir = Path("buf/segmenttest/session")
                segment_dir.mkdir(parents=True)
                montage.run_tool(base + ["-f", "lavfi", "-i", "testsrc2=size=320x180:rate=30",
                                        "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000",
                                        "-t", "12", "-c:v", "libx264", "-preset", "ultrafast", "-g", "240",
                                        "-sc_threshold", "0", "-c:a", "aac", "-f", "segment",
                                        "-segment_time", "2", "-reset_timestamps", "1",
                                        "-segment_format", "mpegts", "-segment_list_type", "csv",
                                        "-segment_list", str(segment_dir / "segments.csv"),
                                        str(segment_dir / "seg_%09d.ts")])
                (segment_dir / "clock.json").write_text(json.dumps({"anchor": 1000}), encoding="utf-8")
                intervals = list_segments(segment_dir.parent)
                if len(intervals) < 2 or intervals[0].end - intervals[0].start < 7:
                    raise RuntimeError("Long-GOP segment fixture was not generated")
                selected = select_run(intervals, 1003, 1011, 1007)
                if len(selected) < 2 or selected[0] != intervals[0]:
                    raise RuntimeError("Overlapping long first segment was lost")
                ctx = ChannelCtx("segmenttest", threading.Event())
                jobs = queue.Queue(maxsize=1)
                ctx.cut_slots.acquire()
                cut_clip(ctx, 1007, 1001, 1011, jobs)
                job = jobs.get_nowait()
                if not 9.5 <= job["duration"] <= 10.1:
                    raise RuntimeError(f"Unexpected real cut duration: {job['duration']}")
                Path(job["path"]).unlink()
                print("OFFLINE MEDIA CHECK: OK (render, assets, top-camera/bottom-content pixel checks, no nickname, segments, cut)", flush=True)
            finally:
                os.chdir(previous)
        return 0
    finally:
        os.chdir(previous)
        montage.SPONSOR["banner"] = old_banner
        montage.MUSIC.clear()
        montage.MUSIC.update(old_music)
        montage.SUBS["enabled"] = old_subs
        for key, value in old_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value


def check_video_effects(base, render_path):
    """Real pixels: source ROI, mirror, camera zoom, banner position/orientation."""
    from unittest.mock import patch
    from render_settings import save_options
    ffmpeg = base[0]
    montage.run_tool(base + ["-f", "lavfi", "-i", "color=c=black:s=640x360:r=30",
        "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000", "-vf",
        "drawbox=x=0:y=0:w=160:h=120:color=red:t=fill,"
        "drawbox=x=160:y=0:w=160:h=120:color=yellow:t=fill,"
        "drawbox=x=0:y=0:w=6:h=120:color=white:t=fill,"
        "drawbox=x=320:y=0:w=160:h=360:color=cyan:t=fill,"
        "drawbox=x=480:y=0:w=160:h=360:color=blue:t=fill",
        "-t", "1.5", "-c:v", "libx264", "-preset", "ultrafast", "-c:a", "aac", "asymmetric.mp4"])
    montage.run_tool(base + ["-f", "lavfi", "-i", "color=c=white:s=320x100:r=30",
        "-vf", "drawbox=x=0:y=0:w=160:h=100:color=magenta:t=fill",
        "-t", "1", "-c:v", "libx264", "-pix_fmt", "yuv420p", "asymmetric_banner.mp4"])
    options = {"split_camera": True, "video_variation": False,
        "banner": str(Path("asymmetric_banner.mp4").resolve()), "music": "",
        "crops": {"effectstest": {"camera": [0, 0, 0.5, 1 / 3],
            "content": [0.5, 0, 0.5, 1], "banner": [0.1, 0.75, 0.6, 0.12]}}}
    job = {"channel": "effectstest", "path": str(Path("asymmetric.mp4").resolve()),
           "ts": 10, "offset": 0, "duration": 1}

    def frame(path):
        return montage.run_tool([ffmpeg, "-loglevel", "error", "-i", path, "-frames:v", "1",
            "-vf", "scale=108:192", "-f", "rawvideo", "-pix_fmt", "rgb24", "pipe:1"],
            capture_output=True).stdout

    def pixel(data, x, y):
        index = (y * 108 + x) * 3
        return tuple(data[index:index + 3])

    def expect(data, x, y, colour, label, tolerance=22):
        actual = pixel(data, x, y)
        if len(actual) != 3 or max(abs(a - b) for a, b in zip(actual, colour)) > tolerance:
            raise RuntimeError(f"{label}: got {actual}, expected {colour}")

    save_options(render_path, options)
    out, _, _ = montage.make_vertical(job)
    before = frame(out)
    expect(before, 27, 32, (255, 0, 0), "original camera left")
    expect(before, 81, 32, (255, 255, 0), "original camera right")
    expect(before, 27, 128, (0, 255, 255), "original content left")
    expect(before, 81, 128, (0, 0, 255), "original content right")
    expect(before, 0, 32, (255, 255, 255), "camera border before zoom", tolerance=45)
    if job['render']['video_effects']:
        raise RuntimeError("Disabled effects unexpectedly enabled")
    effects = {"mirror": True, "brightness": 0.008, "contrast": 1.018,
               "saturation": 0.98, "camera_zoom": 1.06}
    options["video_variation"] = True
    save_options(render_path, options)
    job['ts'] = 11
    with patch('montage.choose_video_effects', return_value=effects) as choose:
        out, _, _ = montage.make_vertical(job)
        choose.assert_called_once_with(True)
    after = frame(out)
    expect(after, 27, 32, (255, 255, 0), "mirrored camera left")
    expect(after, 81, 32, (255, 0, 0), "mirrored camera right")
    expect(after, 27, 128, (0, 0, 255), "mirrored content left")
    expect(after, 81, 128, (0, 255, 255), "mirrored content right")
    expect(after, 107, 32, (255, 0, 0), "camera border cropped by zoom")
    for image, outside in ((before, (0, 255, 255)), (after, (0, 0, 255))):
        expect(image, 18, 153, (255, 0, 255), "banner stays left-magenta at chosen position")
        expect(image, 68, 153, (255, 255, 255), "banner stays right-white at chosen position")
        expect(image, 5, 153, outside, "outside banner rectangle")
    for x in (18, 68):
        if max(abs(a - b) for a, b in zip(pixel(before, x, 153), pixel(after, x, 153))) > 6:
            raise RuntimeError("Video colour effects leaked into banner")
    if job['render']['video_effects'] != effects:
        raise RuntimeError("Applied video effects were not recorded")
    options['split_camera'] = False
    save_options(render_path, options)
    job['ts'] = 12
    with patch('montage.choose_video_effects', return_value=effects):
        out, _, _ = montage.make_vertical(job)
    fallback = frame(out)
    expect(fallback, 27, 96, (0, 0, 255), "fallback mirrored content")
    expect(fallback, 18, 153, (255, 0, 255), "fallback banner not mirrored")
    print("VIDEO EFFECTS CHECK: OK (ROI before mirror, camera zoom, subtle colour, banner position/orientation)", flush=True)


if __name__ == "__main__":
    raise SystemExit(run())
