"""Headless integration check of the real GUI callbacks (no Twitch connection)."""
import inspect
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import MagicMock, patch

import launcher


class FakeVariable:
    def __init__(self, value="", **kwargs):
        self.value = value
        self.traces = []

    def get(self):
        return self.value

    def set(self, value):
        self.value = value
        for callback in self.traces:
            callback()

    def trace_add(self, mode, callback):
        self.traces.append(callback)


def widget_factory(storage):
    def create(*args, **kwargs):
        widget = MagicMock()
        widget.options = dict(kwargs)
        widget.bindings = {}
        widget.alive = True
        widget.winfo_exists.side_effect = lambda: widget.alive
        widget.configure.side_effect = lambda **options: widget.options.update(options)
        widget.bind.side_effect = lambda event, callback, *args: widget.bindings.update({event: callback})
        widget.destroy.side_effect = lambda: setattr(widget, "alive", False)
        widget.get_children.return_value = ()
        widget.selection.return_value = ()
        widget.get.return_value = ""
        widget.index.return_value = "1.0"
        current = {"index": 0}
        def select(index=None):
            if index is not None:
                current["index"] = index
                variable = widget.options.get("textvariable")
                if variable is not None:
                    variable.set(widget.options["values"][index])
            return current["index"]
        widget.current.side_effect = select
        storage.append(widget)
        return widget
    return create


class GuiLanguageTests(unittest.TestCase):
    def test_switch_while_running_and_restore_on_next_launch(self):
        import chat_settings
        tk, ttk = MagicMock(), MagicMock()
        widgets, roots = [], []
        tk.ttk = ttk
        tk.StringVar.side_effect = tk.BooleanVar.side_effect = FakeVariable
        tk.Tk.side_effect = widget_factory(roots)
        for name in ("Toplevel", "Text", "Canvas"):
            getattr(tk, name).side_effect = widget_factory(widgets)
        for name in ("Frame", "Label", "LabelFrame", "Entry", "Checkbutton", "Button", "Combobox", "Treeview", "Scrollbar"):
            getattr(ttk, name).side_effect = widget_factory(widgets)
        tk.scrolledtext.ScrolledText.side_effect = widget_factory(widgets)
        fake_process = MagicMock()
        fake_process.poll.return_value = None
        with tempfile.TemporaryDirectory() as work:
            directory = Path(work)
            with patch.dict("sys.modules", {"tkinter": tk, "tkinter.ttk": ttk,
                                           "tkinter.filedialog": tk.filedialog,
                                           "tkinter.messagebox": tk.messagebox,
                                           "tkinter.scrolledtext": tk.scrolledtext}), \
                 patch.object(launcher, "default_root", return_value=directory), \
                 patch.object(launcher.subprocess, "Popen", return_value=fake_process) as popen, \
                 patch.object(launcher.threading, "Thread"):
                launcher.gui()
                language_combo = next(w for w in widgets if w.options.get("values") == ("Русский", "English"))
                start = next(w for w in widgets if w.options.get("text") == "Запустить")
                local = inspect.getclosurevars(start.options["command"]).nonlocals
                language = local["i18n"]
                panel = local["render_panel"]
                local["channels_var"].set("example_channel")
                panel.refresh_channels()
                self.assertEqual(language.language, "ru")
                panel.data["crops"] = {"example_channel": {"camera": [0, 0, .25, .25]}}
                panel.kinds.current(1)
                panel._select_kind()
                draft_crop = panel.data["crops"].copy()
                editor = chat_settings.ChatPhraseEditor(roots[0], directory / "chat.json", lambda text: None, language)
                editor.phrase.set("моя несохранённая фраза")
                editor.variants.get.return_value = "другой вариант"
                def change(name):
                    language_combo.options["textvariable"].set(name)
                    language_combo.bindings["<<ComboboxSelected>>"](None)
                change("English")
                self.assertEqual(start.options["text"], "Start")
                self.assertEqual(panel.key(), "content")
                self.assertEqual(panel.kind.get(), "Main frame")
                self.assertEqual(panel.data["crops"], draft_crop)
                self.assertEqual(editor.phrase.get(), "моя несохранённая фраза")
                self.assertEqual(editor.variants.get(), "другой вариант")
                self.assertTrue(editor.dirty)
                self.assertEqual(editor.feedback.get(), "Add a phrase and its variants.")
                self.assertEqual(json.loads((directory / "settings.json").read_text())["language"], "en")
                start.options["command"]()
                command = popen.call_args.args[0]
                self.assertEqual(command[command.index("--language") + 1], "en")
                self.assertEqual(start.options["state"], "disabled")
                set_status = local["set_status"]
                set_status("status.recording")
                status = inspect.getclosurevars(set_status).nonlocals["status_var"]
                change("Русский")
                self.assertEqual(status.get(), "Запись идёт — ожидание интересных моментов")
                self.assertEqual(start.options["state"], "disabled")
                change("English")
                self.assertEqual(status.get(), "Recording — waiting for interesting moments")
                # Destroyed children must not prevent later updates.
                editor.window.destroy()
                language.set_language("ru")
                language.set_language("en")
                widgets.clear()
                launcher.gui()
                self.assertTrue(any(w.options.get("text") == "Start" for w in widgets))
                self.assertFalse(any(w.options.get("text") == "Запустить" for w in widgets))
                self.assertEqual(tk.messagebox.showerror.call_count, 0)


if __name__ == "__main__":
    unittest.main()
