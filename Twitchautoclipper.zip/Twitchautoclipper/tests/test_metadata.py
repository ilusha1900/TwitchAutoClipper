"""Offline metadata tests. Real MP4 checks run when FFmpeg/FFprobe are available."""
from datetime import datetime, timezone
import json
from pathlib import Path
import queue
import re
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock, patch

import montage
from render_settings import read_options, save_options


class MetadataTests(unittest.TestCase):
    def test_independent_tags_and_valid_utc_dates(self):
        samples = [montage.choose_clip_metadata() for _ in range(30)]
        for sample in samples:
            tags = sample['format']
            self.assertEqual(set(tags), {'title', 'artist', 'album', 'comment',
                                         'creation_time', 'encoding_tool', 'producer', 'encoder'})
            created = datetime.fromisoformat(tags['creation_time'].replace('Z', '+00:00'))
            self.assertGreaterEqual(created, datetime(2020, 1, 1, tzinfo=timezone.utc))
            self.assertLess(created, datetime.now(timezone.utc))
            for scope in ('video', 'audio'):
                self.assertEqual(sample[scope]['creation_time'], tags['creation_time'])
                self.assertRegex(sample[scope]['handler_name'], r'^[A-Za-z]+_[0-9a-f]{32}$')
            for key in ('title', 'artist', 'album', 'comment'):
                self.assertRegex(tags[key], r'^[A-Za-z]+_[0-9a-f]{32}$')
            for key in ('encoding_tool', 'producer', 'encoder'):
                self.assertEqual(tags[key], 'CapCut')
        self.assertEqual(len({s['format']['title'] for s in samples}), len(samples))
        self.assertGreater(len({s['format']['creation_time'] for s in samples}), 1)
        self.assertEqual(json.loads(json.dumps(samples)), samples)

    def test_disabled_randomization_keeps_capcut_application_tags(self):
        metadata = montage.choose_clip_metadata(False)
        self.assertEqual(metadata['format'], {'encoding_tool': 'CapCut', 'producer': 'CapCut', 'encoder': 'CapCut'})
        self.assertEqual(metadata['video'], {'encoder': 'CapCut'})
        self.assertEqual(metadata['audio'], {'encoder': 'CapCut'})
        self.assertEqual(montage.clip_metadata_args({}), [])

    def test_ffmpeg_arguments_strip_inherited_tags_and_chapters(self):
        metadata = montage.choose_clip_metadata()
        args = montage.clip_metadata_args(metadata)
        for option in ('-map_metadata', '-map_metadata:s', '-map_chapters'):
            self.assertEqual(args[args.index(option) + 1], '-1')
        self.assertEqual(args[args.index('-fflags') + 1], '+bitexact')
        for scope, flag in (('format', '-metadata'), ('video', '-metadata:s:v:0'),
                            ('audio', '-metadata:s:a:0')):
            values = [args[i + 1] for i, arg in enumerate(args) if arg == flag]
            self.assertEqual(values, [f'{montage.ENCODER_KEY if scope == "format" and key == "encoder" else key}={value}'
                                      for key, value in metadata[scope].items()])
        self.assertNotIn('-c:v', args)
        self.assertNotIn('-c:a', args)

    def test_random_filename_is_reserved_and_collision_does_not_overwrite(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(montage, 'OUT_DIR', directory):
            existing = Path(directory) / ('clip_' + 'a' * 32 + '.mp4')
            existing.write_bytes(b'keep existing clip')
            sidecar = Path(directory) / ('clip_' + 'b' * 32 + '.mp4.json')
            sidecar.write_text('keep sidecar', encoding='utf-8')
            with patch.object(montage.uuid, 'uuid4', side_effect=[
                    SimpleNamespace(hex='a' * 32), SimpleNamespace(hex='b' * 32),
                    SimpleNamespace(hex='c' * 32)]):
                out = montage.reserve_clip_path({'channel': 'test', 'ts': 1})
            self.assertEqual(Path(out).name, 'clip_' + 'c' * 32 + '.mp4')
            self.assertEqual(Path(out).read_bytes(), b'')
            self.assertEqual(existing.read_bytes(), b'keep existing clip')
            self.assertEqual(sidecar.read_text(encoding='utf-8'), 'keep sidecar')

    def test_collision_limit_and_legacy_filename(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(montage, 'OUT_DIR', directory):
            job = {'channel': 'test', 'ts': 1.25}
            self.assertEqual(Path(montage.reserve_clip_path(job, False)).name, 'test_1250.mp4')
            with patch.object(montage.uuid, 'uuid4', return_value=SimpleNamespace(hex='a' * 32)):
                first = montage.reserve_clip_path(job)
                with self.assertRaises(FileExistsError):
                    montage.reserve_clip_path(job)
            self.assertTrue(Path(first).exists())

    def test_option_roundtrip_and_panel_defaults(self):
        from render_settings import RenderPanel
        for enabled in (True, False):
            with self.subTest(enabled=enabled), tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / 'render.json'
                save_options(path, {'random_metadata': enabled, 'crops': {}})
                self.assertIs(read_options(path)['random_metadata'], enabled)
                tk, ttk = MagicMock(), MagicMock()
                with patch.dict('sys.modules', {'tkinter': tk, 'tkinter.ttk': ttk}):
                    panel = RenderPanel(MagicMock(), path, lambda: 'test', lambda: directory, MagicMock())
                self.assertEqual(tk.BooleanVar.call_args_list[-1].kwargs, {'value': enabled})
                panel.banner.get.return_value = panel.music.get.return_value = ''
                panel.enabled.get.return_value = True
                panel.variation.get.return_value = False
                panel.random_metadata.get.return_value = not enabled
                panel.store()
                self.assertIs(read_options(path)['random_metadata'], not enabled)
        with tempfile.TemporaryDirectory() as directory:
            tk, ttk = MagicMock(), MagicMock()
            with patch.dict('sys.modules', {'tkinter': tk, 'tkinter.ttk': ttk}):
                RenderPanel(MagicMock(), Path(directory) / 'absent.json', lambda: '', lambda: directory, MagicMock())
            self.assertEqual(tk.BooleanVar.call_args_list[-1].kwargs, {'value': True})


class MontageMetadataTests(unittest.TestCase):
    def test_make_vertical_default_and_disabled_command(self):
        for enabled in (True, False):
            with self.subTest(enabled=enabled), tempfile.TemporaryDirectory() as directory:
                options = {'banner': '', 'music': '', 'video_variation': False}
                if not enabled:
                    options['random_metadata'] = False
                job = {'channel': 'test', 'path': str(Path(directory) / 'input.mp4'),
                       'ts': 2, 'offset': 0, 'duration': 1}
                with patch.object(montage, 'OUT_DIR', directory), \
                     patch.object(montage, 'read_options', return_value=options), \
                     patch.object(montage, 'probe_size', return_value=(320, 180)), \
                     patch.object(montage, 'probe_fps', return_value=30), \
                     patch.object(montage, 'finalize_encoder_tag') as finalize, \
                     patch.object(montage, 'probe_duration', return_value=1), \
                     patch.object(montage, 'tool', return_value='ffmpeg'), \
                     patch.dict(montage.SUBS, enabled=False), \
                     patch.object(montage, 'run_tool') as run:
                    out, _, sponsored = montage.make_vertical(job)
                command = run.call_args.args[0]
                self.assertEqual(command[-1], out)
                self.assertFalse(sponsored)
                self.assertEqual(command[command.index('-c:v') + 1], 'libx264')
                self.assertEqual(command[command.index('-c:a') + 1], 'aac')
                self.assertEqual(job['render']['video_effects'], {})
                self.assertIs(job['render']['random_metadata'], enabled)
                if enabled:
                    self.assertRegex(Path(out).name, r'^clip_[0-9a-f]{32}\.mp4$')
                    self.assertIn('+faststart+use_metadata_tags', command)
                    for key, value in job['render']['metadata']['format'].items():
                        self.assertIn(f'{montage.ENCODER_KEY if key == "encoder" else key}={value}', command)
                else:
                    self.assertEqual(Path(out).name, 'test_2000.mp4')
                    self.assertEqual(job['render']['metadata']['format']['encoder'], 'CapCut')
                    self.assertIn('-map_metadata', command)
                    self.assertIn('-fflags', command)
                    self.assertIn('+faststart+use_metadata_tags', command)
                finalize.assert_called_once_with(out)

    def test_render_failure_cleans_reserved_file_but_keeps_source(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / 'source.mp4'
            source.write_bytes(b'original')
            job = {'channel': 'test', 'path': str(source), 'ts': 1, 'offset': 0, 'duration': 1}
            with patch.object(montage, 'OUT_DIR', directory), \
                 patch.object(montage, 'read_options', return_value={'video_variation': False}), \
                 patch.object(montage, 'probe_size', side_effect=ValueError('bad video')):
                with self.assertRaisesRegex(ValueError, 'bad video'):
                    montage.make_vertical(job)
            self.assertEqual(list(Path(directory).iterdir()), [source])
            self.assertEqual(source.read_bytes(), b'original')

    def test_worker_writes_sidecar_with_original_channel_and_sampled_tags(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / 'source.mp4'
            source.write_bytes(b'raw')
            out = Path(directory) / 'clip_random.mp4'
            out.write_bytes(b'finished')
            metadata = montage.choose_clip_metadata()
            job = {'channel': 'test', 'path': str(source), 'ts': 123,
                   'trigger': {'reason': 'chat'}, 'render': {'random_metadata': True, 'metadata': metadata}}
            jobs, stop = queue.Queue(), MagicMock()
            jobs.put(job)
            stop.is_set.side_effect = [False, True]
            with patch.object(montage, 'make_vertical', return_value=(str(out), '#stream #ad', True)):
                montage.montage_worker(jobs, stop)
            sidecar = json.loads(Path(str(out) + '.json').read_text(encoding='utf-8'))
            self.assertEqual(sidecar['channel'], 'test')
            self.assertEqual(sidecar['trigger_ts'], 123)
            self.assertEqual(sidecar['trigger'], {'reason': 'chat'})
            self.assertEqual(sidecar['render']['metadata'], metadata)
            self.assertEqual(sidecar['path'], str(out.resolve()))
            self.assertEqual(sidecar['caption'], '#stream #ad')
            self.assertTrue(sidecar['sponsored'])
            self.assertFalse(source.exists())
            self.assertTrue(out.exists())
            self.assertEqual(jobs.unfinished_tasks, 0)


class RealMP4MetadataTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            cls.ffmpeg, cls.ffprobe = montage.tool('ffmpeg'), montage.tool('ffprobe')
        except FileNotFoundError as error:
            raise unittest.SkipTest(str(error))

    def test_real_mp4_tags_unique_names_unchanged_media_and_legacy_mode(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / 'source.mp4'
            chapters = root / 'chapters.txt'
            chapters.write_text(';FFMETADATA1\n[CHAPTER]\nTIMEBASE=1/1000\nSTART=0\nEND=500\n'
                                'title=SOURCE_CHAPTER\n', encoding='utf-8')
            montage.run_tool([self.ffmpeg, '-v', 'error', '-y',
                              '-f', 'lavfi', '-i', 'testsrc2=size=320x180:rate=30',
                              '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=48000',
                              '-i', str(chapters), '-t', '1.2', '-map', '0:v', '-map', '1:a',
                              '-map_chapters', '2', '-c:v', 'libx264', '-preset', 'ultrafast',
                              '-c:a', 'aac', '-metadata', 'title=SOURCE_TITLE',
                              '-metadata', 'artist=SOURCE_ARTIST', '-metadata', 'source_secret=SOURCE_SECRET',
                              '-metadata', 'creation_time=2010-01-01T00:00:00Z',
                              '-metadata:s:v:0', 'handler_name=SOURCE_VIDEO',
                              '-metadata:s:a:0', 'handler_name=SOURCE_AUDIO',
                              '-movflags', '+use_metadata_tags', str(source)], capture_output=True)
            output_dir = root / 'ready'
            outputs, samples, hashes = [], [], []
            for enabled in (True, True, False):
                job = {'channel': 'test', 'path': str(source), 'ts': 1, 'offset': 0, 'duration': 1}
                options = {'random_metadata': enabled, 'video_variation': False, 'random_fps': False,
                           'banner': '', 'music': '', 'split_camera': False}
                with patch.object(montage, 'OUT_DIR', str(output_dir)), \
                     patch.object(montage, 'read_options', return_value=options), \
                     patch.dict(montage.SUBS, enabled=False):
                    out, _, _ = montage.make_vertical(job)
                outputs.append(out)
                samples.append(job['render']['metadata'])
                result = montage.run_tool([self.ffprobe, '-v', 'error', '-show_format',
                                           '-show_streams', '-show_chapters', '-of', 'json', out],
                                          capture_output=True, text=True, encoding='utf-8')
                actual = json.loads(result.stdout)
                streams = {s['codec_type']: s for s in actual['streams']}
                video, audio = streams['video'], streams['audio']
                self.assertEqual((video['codec_name'], video['width'], video['height']), ('h264', 1080, 1920))
                self.assertEqual(video['r_frame_rate'], '30/1')
                self.assertEqual(audio['codec_name'], 'aac')
                self.assertEqual(audio['sample_rate'], '48000')
                self.assertLess(abs(float(actual['format']['duration']) - 1), 0.1)
                if enabled:
                    self.assertRegex(Path(out).name, r'^clip_[0-9a-f]{32}\.mp4$')
                    self.assertEqual(actual['chapters'], [])
                    self.assertNotIn('SOURCE_', result.stdout)
                    self.assertEqual(actual['format']['tags']['encoder'], 'CapCut')
                    for key, value in job['render']['metadata']['format'].items():
                        self.assertEqual(actual['format']['tags'][key], value)
                    for scope, stream in (('video', video), ('audio', audio)):
                        self.assertEqual(stream['tags']['handler_name'], samples[-1][scope]['handler_name'])
                        observed = datetime.fromisoformat(stream['tags']['creation_time'].replace('Z', '+00:00'))
                        expected = datetime.fromisoformat(samples[-1][scope]['creation_time'].replace('Z', '+00:00'))
                        self.assertEqual(observed, expected)
                        # FFmpeg 4 omits stream encoder with bitexact; 9 preserves
                        # the explicit application name. Neither may expose Lavc.
                        self.assertIn(stream['tags'].get('encoder'), (None, 'CapCut'))
                else:
                    self.assertEqual(Path(out).name, 'test_1000.mp4')
                    self.assertEqual(samples[-1]['format']['encoder'], 'CapCut')
                self.assertEqual(actual['format']['tags']['encoding_tool'], 'CapCut')
                self.assertEqual(actual['format']['tags']['encoder'], 'CapCut')
                self.assertNotIn('Lavf', result.stdout)
                self.assertNotIn('Lavc', result.stdout)
                # Decode every frame/sample: random metadata must not affect pixels or sound.
                hashes.append(montage.run_tool([self.ffmpeg, '-v', 'error', '-i', out,
                                               '-map', '0:v:0', '-map', '0:a:0', '-f', 'framemd5', '-'],
                                              capture_output=True).stdout)
            self.assertEqual(len(set(outputs)), 3)
            self.assertNotEqual(samples[0]['format']['title'], samples[1]['format']['title'])
            self.assertEqual(hashes[0], hashes[1])
            self.assertEqual(hashes[0], hashes[2])
            self.assertTrue(source.exists())


if __name__ == '__main__':
    unittest.main()
