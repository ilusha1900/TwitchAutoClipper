/* Linux x86-64 harness: exercises PE machine code with Windows-ABI API stubs.
 * This does NOT test the real Windows loader, ShellExecute, or PowerShell.
 * gcc -std=c11 -O2 tests/native_launcher_test.c -o native_launcher_test
 * ./native_launcher_test Twitchautoclipper.exe
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <uchar.h>
#include <setjmp.h>
#include <sys/mman.h>
#define MS __attribute__((ms_abi))
static jmp_buf escape;
static int mode, exited, shell_called, message_called;
static const char16_t *source_path;
static uint16_t rd16(const void *p) { uint16_t v; memcpy(&v,p,2); return v; }
static uint32_t rd32(const void *p) { uint32_t v; memcpy(&v,p,4); return v; }
static size_t len16(const uint16_t *p) { size_t n=0; while(p[n]) n++; return n; }
static int eq16(const uint16_t *a, const char16_t *b) {
    while(*a && *b && *a==(uint16_t)*b) {a++; b++;} return *a==0 && *b==0;
}
static uint32_t MS filename(void *h, uint16_t *out, uint32_t size) {
    (void)h; if(mode==4) return 0; size_t n=len16((const uint16_t*)source_path);
    if(n>=size) return size;
    memcpy(out,source_path,(n+1)*2);
    return (uint32_t)n;
}
static uint32_t MS attributes(const uint16_t *path) {
    if(!eq16(path,u"C:\\Тест папка\\start.cmd")) {fprintf(stderr,"Wrong script path\n"); abort();}
    return mode==2 ? UINT32_MAX : 0x20;
}
static void MS finish(uint32_t code) { exited=(int)code; longjmp(escape,1); }
static intptr_t MS shell(void *hwnd, const uint16_t *op, const uint16_t *file,
                         const uint16_t *params, const uint16_t *cwd, int show) {
    if(hwnd || params || show!=1 || !eq16(op,u"open") ||
       !eq16(file,u"C:\\Тест папка\\start.cmd") || !eq16(cwd,u"C:\\Тест папка")) {
        fprintf(stderr,"Wrong ShellExecute arguments\n"); abort();
    }
    shell_called++; return mode==3 ? 2 : 33;
}
static int MS message(void *h, const uint16_t *text, const uint16_t *title, unsigned flags) {
    (void)h; (void)text; (void)title; if(flags!=16) abort(); message_called++; return 1;
}
static void *stub(const char *name) {
    if(!strcmp(name,"GetModuleFileNameW")) return filename;
    if(!strcmp(name,"GetFileAttributesW")) return attributes;
    if(!strcmp(name,"ExitProcess")) return finish;
    if(!strcmp(name,"ShellExecuteW")) return shell;
    if(!strcmp(name,"MessageBoxW")) return message;
    fprintf(stderr,"Unexpected import: %s\n",name); exit(2);
}
int main(int argc,char **argv) {
    if(argc!=2) return 2;
    FILE *f=fopen(argv[1],"rb"); if(!f) return 2;
    fseek(f,0,SEEK_END); long size=ftell(f); rewind(f);
    uint8_t *file=malloc((size_t)size); if(!file || fread(file,1,(size_t)size,f)!=(size_t)size) return 2; fclose(f);
    uint32_t pe=rd32(file+60); if(memcmp(file+pe,"PE\0\0",4)) return 2;
    uint8_t *opt=file+pe+24; uint32_t image_size=rd32(opt+56), entry=rd32(opt+16);
    uint8_t *mem=mmap(NULL,image_size,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    if(mem==MAP_FAILED) return 2;
    unsigned sections=rd16(file+pe+6), opt_size=rd16(file+pe+20);
    for(unsigned i=0;i<sections;i++) {
        uint8_t *sec=opt+opt_size+40*i;
        memcpy(mem+rd32(sec+12),file+rd32(sec+20),rd32(sec+16));
    }
    uint8_t *desc=mem+rd32(opt+120);
    for(;rd32(desc);desc+=20) {
        uint64_t *lookup=(uint64_t*)(mem+rd32(desc));
        uint64_t *iat=(uint64_t*)(mem+rd32(desc+16));
        for(unsigned i=0;lookup[i];i++) iat[i]=(uintptr_t)stub((char*)mem+lookup[i]+2);
    }
    if(mprotect(mem+4096,4096,PROT_READ|PROT_EXEC)) return 2;
    typedef void (MS *entrypoint)(void);
    for(mode=1;mode<=5;mode++) {
        source_path = mode==5 ? u"bad" : u"C:\\Тест папка\\Twitchautoclipper.exe";
        exited=-1; shell_called=message_called=0;
        if(!setjmp(escape)) ((entrypoint)(mem+entry))();
        int expected=mode==1?0:1;
        if(exited!=expected || shell_called!=(mode==1 || mode==3) || message_called!=(mode!=1)) {
            fprintf(stderr,"Case %d failed: exit=%d shell=%d message=%d\n",mode,exited,shell_called,message_called);return 1;
        }
        printf("Native machine-code case %d: OK\n",mode);
    }
    munmap(mem,image_size); free(file); return 0;
}
