"""Offline tests for render options, crop geometry and human-readable triggers."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch, MagicMock
from types import SimpleNamespace
from detector import MomentDetector
from main import describe_trigger
from montage import build_filter, crop_pixels, pick_music, choose_video_effects
from render_settings import read_options, save_options, validate_roi, RenderPanel


class RenderTests(unittest.TestCase):
    def test_roi_validation(self):
        self.assertEqual(validate_roi([0.1, 0.2, 0.3, 0.4]), [0.1, 0.2, 0.3, 0.4])
        self.assertIsNone(validate_roi(None))
        for roi in ([0, 0, 0, 1], [-1, 0, 1, 1], [0.8, 0, 0.3, 1],
                    [0, 0, float('nan'), 1], [0, 0, 1]):
            with self.subTest(roi=roi), self.assertRaises(ValueError):
                validate_roi(roi)

    def test_crop_even_and_in_bounds(self):
        w, h, x, y = crop_pixels(1919, 1079, [0.75, 0.7, 0.25, 0.3])
        self.assertEqual(w % 2, 0)
        self.assertEqual(h % 2, 0)
        self.assertLessEqual(x + w, 1919)
        self.assertLessEqual(y + h, 1079)
        self.assertGreaterEqual(min(x, y), 0)

    def test_layout_camera_top_content_bottom_no_nickname(self):
        graph = build_filter(1920, 1080, None, False,
                             camera_roi=[0, 0, 0.25, 0.3], content_roi=[0.25, 0, 0.75, 1])
        self.assertIn('[cam][screen]vstack=inputs=2', graph)
        self.assertIn('scale=1080:640', graph)
        self.assertIn('scale=1080:1280', graph)
        self.assertNotIn('drawtext', graph)
        self.assertNotIn('fontfile', graph)

    def test_fallback_also_has_no_nickname(self):
        graph = build_filter(1920, 1080, None, False)
        self.assertNotIn('drawtext', graph)
        self.assertNotIn('vstack', graph)

    def test_saved_paths_and_per_channel_regions(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'render.json'
            options = {'banner': 'C:/Ads/banner.mp4', 'music': 'C:/Music',
                       'crops': {'a': {'camera': [0, 0, 0.2, 0.3]},
                                 'b': {'camera': [0.8, 0.7, 0.2, 0.3]}}, 'split_camera': True}
            save_options(path, options)
            self.assertEqual(read_options(path), options)
            self.assertFalse(path.with_suffix('.tmp').exists())

    def test_explicit_music_file(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / 'selected.wav'
            source.write_bytes(b'placeholder')
            with patch('montage.probe_duration', return_value=60):
                path, start = pick_music(10, str(source))
            self.assertEqual(path, str(source))
            self.assertGreaterEqual(start, 0)
            self.assertLessEqual(start, 49)

    def test_empty_music_disables_track(self):
        self.assertEqual(pick_music(10, ''), (None, 0.0))


class VideoEffectsTests(unittest.TestCase):
    def test_random_effects_have_safe_bounds(self):
        samples = [choose_video_effects() for _ in range(40)]
        for effect in samples:
            self.assertTrue(effect['mirror'])
            self.assertTrue(1.02 <= effect['camera_zoom'] <= 1.06)
            self.assertTrue(-0.012 <= effect['brightness'] <= 0.012)
            self.assertTrue(0.98 <= effect['contrast'] <= 1.02)
            self.assertTrue(0.97 <= effect['saturation'] <= 1.03)
        self.assertGreater(len({effect['camera_zoom'] for effect in samples}), 1)

    def test_disabled_effects_preserve_old_graph(self):
        effects = choose_video_effects(False)
        self.assertEqual(effects, {})
        self.assertEqual(build_filter(1920, 1080, None, True),
                         build_filter(1920, 1080, None, True, video_effects=effects))

    def test_camera_and_content_cropped_before_mirror(self):
        graph = build_filter(1920, 1080, None, True,
                             camera_roi=[0, 0, 0.25, 0.3], content_roi=[0.25, 0, 0.75, 1],
                             video_effects={'mirror': True, 'camera_zoom': 1.04})
        self.assertIn('[cam_src]crop=460:310:10:6,hflip,eq=', graph)
        self.assertIn('[screen_src]crop=1440:1080:480:0,hflip,eq=', graph)
        self.assertEqual(graph.count('hflip'), 2)
        banner = next(part for part in graph.split(';') if part.startswith('[1:v:0]'))
        self.assertNotIn('hflip', banner)
        self.assertNotIn('eq=', banner)
        self.assertLess(graph.index('hflip'), graph.index('[v0][bn]overlay='))

    def test_fallback_mirrors_source_only(self):
        graph = build_filter(640, 360, None, True, video_effects={'mirror': True})
        self.assertIn('[0:v:0]setpts=PTS-STARTPTS,hflip,eq=', graph)
        self.assertEqual(graph.count('hflip'), 1)
        self.assertNotIn('[v0]hflip', graph)

    def test_banner_uses_output_rectangle(self):
        graph = build_filter(1920, 1080, None, True, banner_roi=[0.1, 0.75, 0.4, 0.15])
        self.assertIn('scale=432:288:force_original_aspect_ratio=decrease', graph)
        self.assertIn('overlay=108+(432-w)/2:1440+(288-h)/2:shortest=1', graph)
        self.assertNotIn('overlay=(W-w)/2:650', graph)

    def test_banner_not_added_without_asset(self):
        graph = build_filter(640, 360, None, False, banner_roi=[0, 0, 1, 1],
                             video_effects=choose_video_effects())
        self.assertNotIn('[1:v:0]', graph)

    def test_banner_settings_are_channel_specific(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'render.json'
            options = {'video_variation': False, 'crops': {
                'a': {'banner': [0, 0.5, 0.5, 0.2]},
                'b': {'banner': [0.5, 0, 0.5, 0.3]}}}
            save_options(path, options)
            restored = read_options(path)
            self.assertFalse(restored['video_variation'])
            for channel in ('a', 'b'):
                self.assertEqual(validate_roi(restored['crops'][channel]['banner']),
                                 options['crops'][channel]['banner'])

    def test_no_zoom_when_effects_disabled(self):
        graph = build_filter(1920, 1080, None, False, camera_roi=[0, 0, 0.25, 0.3])
        self.assertIn('[cam_src]crop=480:324:0:0,scale=', graph)
        self.assertNotIn('hflip', graph)

    def test_invalid_zoom_rejected(self):
        for zoom in (0, 1.2, float('nan')):
            with self.subTest(zoom=zoom), self.assertRaises(ValueError):
                build_filter(640, 360, None, False, camera_roi=[0, 0, 0.5, 0.5],
                             video_effects={'camera_zoom': zoom})


class BannerEditorTests(unittest.TestCase):
    def panel(self, path, roi=None):
        panel = RenderPanel.__new__(RenderPanel)
        from i18n import I18n
        panel.i18n = I18n()
        panel.tk, panel.ttk, panel.frame = MagicMock(), MagicMock(), MagicMock()
        panel.channel = MagicMock()
        panel.channel.get.return_value = 'a'
        panel.enabled, panel.variation, panel.random_metadata = MagicMock(), MagicMock(), MagicMock()
        panel.enabled.get.return_value = True
        panel.variation.get.return_value = False
        panel.random_metadata.get.return_value = True
        panel.random_fps = MagicMock()
        panel.random_fps.get.return_value = True
        panel.banner, panel.music = MagicMock(), MagicMock()
        panel.banner.get.return_value = panel.music.get.return_value = ''
        panel.notify = MagicMock()
        panel.path = path
        panel.data = {'crops': {'a': {} if roi is None else {'banner': roi},
                                'b': {'banner': [0, 0, 0.2, 0.2]}}}
        with patch.dict('sys.modules', {'tkinter': MagicMock()}):
            panel.banner_window()
        bindings = dict(call.args for call in panel.tk.Canvas.return_value.bind.call_args_list)
        actions = {{'reset': 'Сбросить', 'accept': 'Сохранить положение'}[call.kwargs['command'].__name__]: call.kwargs['command']
                   for call in panel.ttk.Button.call_args_list}
        return panel, bindings, actions

    def test_resize_all_corners_and_sides(self):
        points = {'nw': (0.25, 0.25), 'ne': (0.75, 0.25),
                  'sw': (0.25, 0.75), 'se': (0.75, 0.75),
                  'n': (0.5, 0.25), 'e': (0.75, 0.5),
                  's': (0.5, 0.75), 'w': (0.25, 0.5)}
        with tempfile.TemporaryDirectory() as directory:
            for handle, (x, y) in points.items():
                with self.subTest(handle=handle):
                    path = Path(directory) / 'render.json'
                    panel, bindings, actions = self.panel(path, [0.25, 0.25, 0.5, 0.5])
                    dx = -0.125 if 'w' in handle else 0.125 if 'e' in handle else 0
                    dy = -0.125 if 'n' in handle else 0.125 if 's' in handle else 0
                    bindings['<Button-1>'](SimpleNamespace(x=x * 288, y=y * 512))
                    bindings['<B1-Motion>'](SimpleNamespace(x=(x + dx) * 288, y=(y + dy) * 512))
                    bindings['<ButtonRelease-1>'](SimpleNamespace(x=(x + dx) * 288, y=(y + dy) * 512))
                    actions['Сохранить положение']()
                    roi = read_options(path)['crops']['a']['banner']
                    left = 0.125 if 'w' in handle else 0.25
                    top = 0.125 if 'n' in handle else 0.25
                    right = 0.875 if 'e' in handle else 0.75
                    bottom = 0.875 if 's' in handle else 0.75
                    self.assertEqual(roi, [left, top, right - left, bottom - top])
                    self.assertEqual(read_options(path)['crops']['b']['banner'], [0, 0, 0.2, 0.2])

    def test_resize_cannot_invert_or_collapse_rectangle(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'render.json'
            panel, bindings, actions = self.panel(path, [0.25, 0.25, 0.5, 0.5])
            bindings['<Button-1>'](SimpleNamespace(x=216, y=384))
            bindings['<ButtonRelease-1>'](SimpleNamespace(x=-100, y=-100))
            actions['Сохранить положение']()
            roi = read_options(path)['crops']['a']['banner']
            self.assertEqual(validate_roi(roi), roi)
            self.assertEqual(roi[:2], [0.25, 0.25])
            self.assertAlmostEqual(roi[2] * 288, 4)
            self.assertAlmostEqual(roi[3] * 512, 4)

    def test_resize_cannot_leave_output_frame(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'render.json'
            panel, bindings, actions = self.panel(path, [0.25, 0.25, 0.5, 0.5])
            bindings['<Button-1>'](SimpleNamespace(x=72, y=128))
            bindings['<ButtonRelease-1>'](SimpleNamespace(x=-500, y=-500))
            actions['Сохранить положение']()
            self.assertEqual(read_options(path)['crops']['a']['banner'], [0, 0, 0.75, 0.75])

    def test_full_frame_banner_can_be_shrunk(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'render.json'
            panel, bindings, actions = self.panel(path, [0, 0, 1, 1])
            bindings['<Button-1>'](SimpleNamespace(x=288, y=512))
            bindings['<ButtonRelease-1>'](SimpleNamespace(x=144, y=256))
            actions['Сохранить положение']()
            self.assertEqual(read_options(path)['crops']['a']['banner'], [0, 0, 0.5, 0.5])

    def test_resize_cursors_and_shift_override(self):
        with tempfile.TemporaryDirectory() as directory:
            panel, bindings, actions = self.panel(Path(directory) / 'render.json', [0.25, 0.25, 0.5, 0.5])
            canvas = panel.tk.Canvas.return_value
            bindings['<Motion>'](SimpleNamespace(x=216, y=256))
            canvas.configure.assert_called_with(cursor='sb_h_double_arrow')
            bindings['<Motion>'](SimpleNamespace(x=144, y=128))
            canvas.configure.assert_called_with(cursor='sb_v_double_arrow')
            bindings['<Motion>'](SimpleNamespace(x=144, y=256))
            canvas.configure.assert_called_with(cursor='fleur')
            bindings['<Motion>'](SimpleNamespace(x=216, y=256, state=1))
            canvas.configure.assert_called_with(cursor='crosshair')

    def test_click_near_handle_does_not_jump(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'render.json'
            panel, bindings, actions = self.panel(path, [0.25, 0.25, 0.5, 0.5])
            bindings['<Button-1>'](SimpleNamespace(x=213, y=382))
            bindings['<ButtonRelease-1>'](SimpleNamespace(x=213, y=382))
            actions['Сохранить положение']()
            self.assertEqual(read_options(path)['crops']['a']['banner'], [0.25, 0.25, 0.5, 0.5])

    def test_draw_save_and_reload(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'render.json'
            panel, bindings, actions = self.panel(path)
            bindings['<Button-1>'](SimpleNamespace(x=0, y=0))
            bindings['<B1-Motion>'](SimpleNamespace(x=144, y=256))
            bindings['<ButtonRelease-1>'](SimpleNamespace(x=144, y=256))
            actions['Сохранить положение']()
            saved = read_options(path)
            self.assertEqual(saved['crops']['a']['banner'], [0, 0, 0.5, 0.5])
            self.assertEqual(saved['crops']['b']['banner'], [0, 0, 0.2, 0.2])
            self.assertFalse(saved['video_variation'])

    def test_shift_draw_resizes_inside_existing_rectangle(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'render.json'
            panel, bindings, actions = self.panel(path)
            bindings['<Button-1>'](SimpleNamespace(x=144, y=200, state=1))
            bindings['<ButtonRelease-1>'](SimpleNamespace(x=216, y=328))
            actions['Сохранить положение']()
            roi = read_options(path)['crops']['a']['banner']
            self.assertEqual(roi, [0.5, 200 / 512, 0.25, 0.25])

    def test_drag_clamps_inside_frame_and_reset_removes_setting(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'render.json'
            panel, bindings, actions = self.panel(path)
            bindings['<Button-1>'](SimpleNamespace(x=144, y=200))
            bindings['<ButtonRelease-1>'](SimpleNamespace(x=1000, y=1000))
            actions['Сохранить положение']()
            roi = read_options(path)['crops']['a']['banner']
            self.assertEqual(validate_roi(roi), roi)
            self.assertAlmostEqual(roi[0] + roi[2], 1)
            self.assertAlmostEqual(roi[1] + roi[3], 1)
            panel.ttk.Button.reset_mock()
            with patch.dict('sys.modules', {'tkinter': MagicMock()}):
                panel.banner_window()
            actions = {{'reset': 'Сбросить', 'accept': 'Сохранить положение'}[call.kwargs['command'].__name__]: call.kwargs['command']
                       for call in panel.ttk.Button.call_args_list}
            actions['Сбросить']()
            actions['Сохранить положение']()
            self.assertNotIn('banner', read_options(path)['crops']['a'])


class TriggerLogTests(unittest.TestCase):
    def test_trigger_explanation_contains_real_cause(self):
        detector = MomentDetector(threshold=1.2, single_threshold=4)
        for user in range(30):
            detector.on_chat('лол', user=str(user))
        self.assertTrue(detector.tick(None, now=0))
        snapshot = detector.last
        explanation = describe_trigger(snapshot)
        self.assertIn('смех', explanation)
        self.assertIn('всплеск чата', explanation)
        self.assertIn('общий score=', explanation)
        self.assertIn('порог 4.00', explanation)
        self.assertIn('вклад в score', explanation)
        self.assertIn('single_chat', snapshot['routes'])
        self.assertIn('combined', snapshot['routes'])
        self.assertEqual(snapshot['chat_categories'], ['laugh'])
        json.dumps(snapshot)


if __name__ == '__main__':
    unittest.main()
