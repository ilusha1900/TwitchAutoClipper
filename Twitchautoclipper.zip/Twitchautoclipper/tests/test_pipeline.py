"""Offline tests: manifest parsing, real intervals, gaps, and channel validation."""
import csv
import json
from pathlib import Path
import tempfile
import unittest
from main import Segment, list_segments, normalize_channels, select_run, Recorder
from unittest.mock import patch
import threading
from montage import _ass_time, chunk_words, build_audio_filter


class SegmentTests(unittest.TestCase):
    def test_long_segment_overlapping_start_is_included(self):
        segments = [Segment(90, 110, "a.ts", "one"), Segment(110, 130, "b.ts", "one")]
        result = select_run(segments, lo=100, hi=120, trigger_ts=115)
        self.assertEqual([segment.path for segment in result], ["a.ts", "b.ts"])

    def test_run_containing_trigger_beats_nearby_midpoint(self):
        segments = [Segment(0, 5, "a.ts", "old"), Segment(20, 35, "b.ts", "new")]
        result = select_run(segments, lo=0, hi=35, trigger_ts=22)
        self.assertEqual([segment.path for segment in result], ["b.ts"])

    def test_sessions_are_not_joined(self):
        segments = [Segment(0, 10, "a.ts", "one"), Segment(10, 20, "b.ts", "two")]
        result = select_run(segments, 0, 20, 15)
        self.assertEqual([segment.path for segment in result], ["b.ts"])

    def test_real_gap_splits_run(self):
        segments = [Segment(0, 4, "a.ts", "one"), Segment(8, 16, "b.ts", "one")]
        self.assertEqual([s.path for s in select_run(segments, 0, 16, 10)], ["b.ts"])

    def test_no_overlap(self):
        self.assertEqual(select_run([Segment(0, 5, "a", "one")], 10, 20, 15), [])

    def test_manifest_uses_actual_duration_and_ignores_partial_line(self):
        with tempfile.TemporaryDirectory() as root:
            session = Path(root) / "session"
            session.mkdir()
            (session / "clock.json").write_text(json.dumps({"anchor": 1000}), encoding="utf-8")
            (session / "seg_000000000.ts").write_bytes(b"placeholder")
            with open(session / "segments.csv", "w", encoding="utf-8", newline="") as stream:
                csv.writer(stream).writerow(["seg_000000000.ts", "0.0", "7.5"])
                stream.write('"seg_000000001.ts",7.5,')
            result = list_segments(root)
            self.assertEqual(len(result), 1)
            self.assertEqual(result[0].start, 1000)
            self.assertEqual(result[0].end, 1007.5)

    def test_missing_or_invalid_clock_ignored(self):
        with tempfile.TemporaryDirectory() as root:
            session = Path(root) / "session"
            session.mkdir()
            (session / "segments.csv").write_text("seg_000000000.ts,0,2\n", encoding="utf-8")
            self.assertEqual(list_segments(root), [])
            (session / "clock.json").write_text("invalid", encoding="utf-8")
            self.assertEqual(list_segments(root), [])


class AudioSamplingTests(unittest.TestCase):
    def recorder(self):
        return Recorder("test", ".", threading.Event())

    def test_burst_keeps_peak_not_last_quiet_block(self):
        recorder = self.recorder()
        for value in (-30, -12, -50):
            recorder._push_volume(value)
        self.assertEqual(recorder.take_volume(), -12)
        self.assertIsNone(recorder.take_volume())
        self.assertEqual(recorder.volume(), -50)

    def test_next_burst_does_not_reuse_old_peak(self):
        recorder = self.recorder()
        recorder._push_volume(-12)
        recorder.take_volume()
        recorder._push_volume(-40)
        self.assertEqual(recorder.take_volume(), -40)

    def test_hls_pause_does_not_rebaseline_same_audio(self):
        recorder = self.recorder()
        with patch("main.time.monotonic", return_value=100):
            recorder._push_volume(-25)
            self.assertEqual(recorder.take_volume(), -25)
        with patch("main.time.monotonic", return_value=106):
            self.assertEqual(recorder.volume(), -25)
            self.assertIsNone(recorder.take_volume())
        with patch("main.time.monotonic", return_value=111):
            self.assertIsNone(recorder.volume())

    def test_reset_drops_old_session_audio(self):
        recorder = self.recorder()
        recorder._push_volume(-20)
        recorder._reset_audio()
        self.assertIsNone(recorder.take_volume())


class ConfigurationTests(unittest.TestCase):
    def test_normalize_channels(self):
        self.assertEqual(normalize_channels(["Example_Channel, other;example_channel"]), ["example_channel", "other"])
        self.assertEqual(normalize_channels(["https://www.twitch.tv/EXAMPLE_CHANNEL/"]), ["example_channel"])

    def test_bad_channels_rejected(self):
        for values in ([""], ["../data"], ["a&b"], ["https://other.example/name"]):
            with self.subTest(values=values), self.assertRaises(ValueError):
                normalize_channels(values)

    def test_subtitle_chunk_size(self):
        words = [(i * 0.2, i * 0.2 + 0.15, str(i)) for i in range(9)]
        self.assertEqual([len(chunk) for chunk in chunk_words(words)], [4, 4, 1])

    def test_ass_time(self):
        self.assertEqual(_ass_time(3661.25), "1:01:01.25")

    def test_music_timeline_is_bounded_and_reset(self):
        graph = build_audio_filter(1, 10)
        self.assertIn("[1:a:0]atrim=duration=10.000,asetpts=PTS-STARTPTS", graph)
        self.assertIn("sidechaincompress", graph)


if __name__ == "__main__":
    unittest.main(verbosity=2)
