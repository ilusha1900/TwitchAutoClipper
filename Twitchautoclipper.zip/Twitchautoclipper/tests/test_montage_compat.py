"""Regression coverage for the 2026-11-18 FFmpeg 9.0.2 failure log."""
from fractions import Fraction
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch
import wave

import numpy as np
import montage


class FPSCompatibilityTests(unittest.TestCase):
    SOURCES = (Fraction(945787912, 16382555) + Fraction(16, 10),
               Fraction(23439427, 394270) - Fraction(1, 10))

    def test_log_rates_never_create_huge_timebases_or_out_of_range_deltas(self):
        for source in self.SOURCES:
            for step in range(-20, 21):
                if not step:
                    continue
                with self.subTest(source=str(source), delta=step / 10), \
                     patch.object(montage.random, "choice", return_value=Fraction(step, 10)):
                    rate = montage.choose_output_fps(source)
                    self.assertLessEqual(rate.denominator, 100000)
                    self.assertLess(rate.numerator, 2**31 // 2)
                    self.assertTrue(Fraction(1, 10) <= abs(rate - source) <= 2)
                    self.assertLessEqual(abs(rate - source - Fraction(step, 10)), Fraction(1, 1000))
            unchanged = montage.choose_output_fps(source, False)
            self.assertLessEqual(unchanged.denominator, 100000)
            self.assertLessEqual(abs(unchanged - source), Fraction(1, 2000))

    def test_cfr_filter_preserves_original_timeline_after_composition(self):
        graph = montage.build_filter(1920, 1080, None, True,
                                     camera_roi=[0.76, 0.01, 0.23, 0.3],
                                     ass_path="captions.ass", output_fps=Fraction(57731, 1000))
        self.assertTrue(graph.endswith("[v2]fps=fps=57731/1000:round=near[v]"))
        self.assertNotIn("setpts=PTS/", graph)
        self.assertLess(graph.index("overlay="), graph.index("fps=fps="))


class ToolDiagnosticsTests(unittest.TestCase):
    def test_uncaptured_stderr_is_in_exception_and_bounded(self):
        with self.assertRaises(montage.MediaToolError) as context:
            montage.run_tool([sys.executable, "-c", "import sys; sys.stderr.write('x'*50000 + '\\nUnrecognized option vsync'); sys.exit(2)"])
        error = context.exception
        self.assertEqual(error.returncode, 2)
        self.assertIn("Unrecognized option vsync", str(error))
        self.assertLessEqual(len(error.stderr), 12000)
        self.assertIsInstance(error, subprocess.CalledProcessError)

    def test_explicit_capture_keeps_stderr_diagnostics(self):
        with self.assertRaises(montage.MediaToolError) as context:
            montage.run_tool([sys.executable, "-c", "import sys; sys.stderr.write('test failure'); sys.exit(3)"],
                             capture_output=True, text=True)
        self.assertIn("test failure", str(context.exception))
        self.assertEqual(context.exception.returncode, 3)


class SubtitleCompatibilityTests(unittest.TestCase):
    @staticmethod
    def write_wav(path, samples, channels=1, rate=16000):
        with wave.open(str(path), "wb") as audio:
            audio.setnchannels(channels)
            audio.setsampwidth(2)
            audio.setframerate(rate)
            audio.writeframes(np.asarray(samples, dtype="<i2").tobytes())

    def test_decoded_audio_dtype_shape_and_amplitude(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "audio.wav"
            self.write_wav(path, [-32768, 0, 32767])
            audio = montage.load_whisper_audio(path)
            self.assertEqual(audio.dtype, np.float32)
            self.assertEqual(audio.shape, (3,))
            np.testing.assert_allclose(audio, [-1, 0, 32767 / 32768])
            self.write_wav(path, [0, 0], rate=48000)
            with self.assertRaisesRegex(ValueError, "16000"):
                montage.load_whisper_audio(path)

    def test_transcription_bypasses_pyav_file_decoder(self):
        model = Mock()
        def recognize(audio, **kwargs):
            if isinstance(audio, (str, Path)):
                raise TypeError("open() got an unexpected keyword argument 'metadata_errors'")
            self.assertIsInstance(audio, np.ndarray)
            self.assertEqual(audio.dtype, np.float32)
            self.assertEqual(kwargs["language"], "ru")
            words = [SimpleNamespace(start=0.1, end=0.4, word=" тест ")]
            return iter([SimpleNamespace(words=words)]), None
        model.transcribe.side_effect = recognize
        module = SimpleNamespace(WhisperModel=Mock(return_value=model))
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "audio.wav"
            def extract(args, **kwargs):
                self.assertIn("pcm_s16le", args)
                self.write_wav(args[-1], [0, 100, -100] * 1000)
            with patch.dict(sys.modules, {"faster_whisper": module}), \
                 patch.object(montage, "_whisper", None), \
                 patch.object(montage, "tool", return_value="ffmpeg"), \
                 patch.object(montage, "run_tool", side_effect=extract):
                words = montage.transcribe_words("source.mp4", 0, 1, "ru", str(path))
            self.assertEqual(words, [(0.1, 0.4, "тест")])
            module.WhisperModel.assert_called_once()


class RealExportCompatibilityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            cls.ffprobe = montage.tool("ffprobe")
            tools = [montage.tool("ffmpeg")]
        except FileNotFoundError as error:
            raise unittest.SkipTest(str(error))
        # Optional test-only binary; no extra application dependency is needed.
        try:
            import imageio_ffmpeg
            tools.append(imageio_ffmpeg.get_ffmpeg_exe())
        except ImportError:
            pass
        cls.tools = list(dict.fromkeys(str(Path(path).resolve()) for path in tools))

    def test_log_layout_and_rates_on_each_installed_ffmpeg(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, banner = root / "source.mp4", root / "banner.mp4"
            montage.run_tool([self.tools[0], "-v", "error", "-y", "-f", "lavfi", "-i",
                              "color=c=blue:s=1920x1080:r=60", "-f", "lavfi", "-i",
                              "sine=frequency=440:sample_rate=48000", "-t", "2.5",
                              "-c:v", "libx264", "-preset", "ultrafast", "-c:a", "aac", str(source)],
                             capture_output=True)
            montage.run_tool([self.tools[0], "-v", "error", "-y", "-f", "lavfi", "-i",
                              "color=c=green:s=320x100:r=30", "-t", "0.3", "-c:v", "libx264",
                              "-pix_fmt", "yuv420p", str(banner)], capture_output=True)
            options = {"banner": str(banner), "music": "", "video_variation": True,
                       "crops": {"example_channel": {
                           "camera": [0.7645833333333333, 0.012962962962962963, 0.22916666666666666, 0.3037037037037037],
                           "content": [0.00625, 0.13703703703703704, 0.8479166666666667, 0.8629629629629629],
                           "banner": [6/1080, 4/1920, 1072/1080, 1822/1920]}}}
            real_run = montage.run_tool
            for exe in self.tools:
                version = real_run([exe, "-version"], capture_output=True, text=True).stdout.splitlines()[0]
                print(f"COMPAT CHECK: {version}", flush=True)
                for base, delta in zip(FPSCompatibilityTests.SOURCES, (Fraction(-16, 10), Fraction(1, 10))):
                    with self.subTest(ffmpeg=version, fps=str(base), delta=str(delta)):
                        job = {"channel": "example_channel", "path": str(source), "ts": 1,
                               "offset": 0.751, "duration": 1.25}
                        with patch.dict("os.environ", {"FFMPEG_PATH": exe, "FFPROBE_PATH": self.ffprobe}), \
                             patch.object(montage, "OUT_DIR", str(root / "ready")), \
                             patch.object(montage, "read_options", return_value=options), \
                             patch.object(montage, "probe_fps", return_value=base), \
                             patch.object(montage.random, "choice", return_value=delta), \
                             patch.dict(montage.SUBS, enabled=False), \
                             patch.object(montage, "run_tool", wraps=real_run) as calls:
                            out, _, sponsored = montage.make_vertical(job)
                        exports = [call.args[0] for call in calls.call_args_list if "-filter_complex" in call.args[0]]
                        self.assertEqual(len(exports), 1)
                        command = exports[0]
                        self.assertNotIn("-vsync", command)
                        self.assertNotIn("-fps_mode", command)
                        graph = command[command.index("-filter_complex") + 1]
                        self.assertIn("fps=fps=", graph)
                        actual = json.loads(real_run([self.ffprobe, "-v", "error", "-show_format", "-show_streams",
                                                      "-of", "json", out], capture_output=True, text=True).stdout)
                        video, audio = actual["streams"]
                        expected = Fraction(job["render"]["output_fps_ratio"])
                        self.assertEqual(Fraction(video["avg_frame_rate"]), expected)
                        self.assertEqual(Fraction(video["r_frame_rate"]), expected)
                        self.assertTrue(sponsored)
                        self.assertLess(abs(float(video["duration"]) - float(audio["duration"])), 0.1)
                        self.assertEqual(actual["format"]["tags"]["encoder"], "CapCut")
                        real_run([exe, "-v", "error", "-i", out, "-f", "null", "-"], capture_output=True)


if __name__ == "__main__":
    unittest.main()
